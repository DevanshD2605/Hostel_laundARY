# Using your Supabase project

The app talks to Supabase directly (no Express server). Set these two values in `.env` (already filled in for this project):

```
EXPO_PUBLIC_SUPABASE_URL=https://<project>.supabase.co
EXPO_PUBLIC_SUPABASE_KEY=<publishable key, starts with sb_publishable_>
```
Only the **publishable** key belongs in the app. Never use a `service_role` / `sb_secret_` key here.
Leave both empty and the app runs in demo mode instead.

## What works against the real database today (student side)
| Screen | Supabase call |
|---|---|
| Send OTP / Verify | `auth.signInWithOtp`, `auth.verifyOtp` |
| Profile check at login, Home, Profile | RPC `get_student_profile` |
| First-time setup, Edit profile | RPC `register_student` |
| Submit laundry | RPC `submit_laundry_request` |
| History, Home, details | RPC `get_student_laundry_requests` |

Not connected yet (they show "isn't connected to the database yet" or an empty list): pickup QR, complaints, notifications,
and every staff and admin screen. They need more SQL functions of the same kind (security definer, checking who is calling):
`get_my_role`, `staff_list_requests`, `staff_verify_request`, `staff_generate_tag`, `staff_set_status`, `staff_lookup_pickup`,
`staff_confirm_collection`, `create_complaint`, `list_my_notifications`, and the `admin_*` functions.

## Deploy
Add the same two variables in Vercel (Project -> Settings -> Environment Variables) and redeploy.
In Supabase -> Authentication -> URL Configuration, add your Vercel address to the allowed URLs.
