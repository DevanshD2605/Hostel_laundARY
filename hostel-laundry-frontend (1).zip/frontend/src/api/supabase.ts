/**
 * SUPABASE CLIENT — talks straight to Supabase (no Express server).
 * Login = Supabase email OTP. Data = Postgres functions (RPC) that run as SECURITY DEFINER, so the browser only ever holds
 * the publishable key and row-level security stays on. Student features use the functions that already exist
 * (get_student_profile, register_student, submit_laundry_request, get_student_laundry_requests).
 * Staff and admin features need more SQL functions (see docs/SUPABASE.md) and report "not connected yet" until then.
 */
import AsyncStorage from '@react-native-async-storage/async-storage';
import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { Api, ApiError, Batch, Items, Me, Status } from './types';
import { DEFAULT_CATEGORIES, DEFAULT_CONDITIONS, STATUS } from '../constants/domain';
import { CATEGORY_IDS, HOSTELS } from '../constants/hostels';

let client: SupabaseClient | null = null;
const sb = (): SupabaseClient => (client ??= createClient(process.env.EXPO_PUBLIC_SUPABASE_URL || 'http://localhost', process.env.EXPO_PUBLIC_SUPABASE_KEY || 'missing', {
  auth: { storage: AsyncStorage, autoRefreshToken: true, persistSession: true, detectSessionInUrl: false },
}));

const na = (what: string) => async (): Promise<never> => { throw new ApiError(`${what} isn’t connected to the database yet.`, 501); };
const fail = (e: { message: string }) => new ApiError(e.message, 400);

const norm = (x: unknown) => String(x ?? '').replace(/^hostel\s+/i, '').replace(/\s*hostel$/i, '').trim().toUpperCase();
let semester = 'Current semester';

async function profileRow(): Promise<{ email: string; p: Record<string, any> | null }> {
  const { data, error } = await sb().auth.getSession();
  if (error || !data.session?.user.email) throw new ApiError('Not signed in', 401);
  const { data: p, error: e2 } = await sb().rpc('get_student_profile');
  if (e2) throw fail(e2);
  return { email: data.session.user.email.toLowerCase(), p: (Array.isArray(p) ? p[0] : p) ?? null };
}

function toMe(email: string, p: Record<string, any> | null): Me {
  const id = email.split('@')[0].toUpperCase();
  if (!p) return { id, role: 'student', email, name: '', profile: null, enrollment: null };
  const hostelId = norm(p.hostel ?? p.hostel_code ?? p.hostel_name);
  const h = HOSTELS.find((x) => x.id === hostelId);
  if (p.semester) semester = String(p.semester);
  return {
    id, role: 'student', email, name: p.name ?? '',
    profile: {
      name: p.name ?? '', gender: p.gender === 'Girls' || p.gender === 'Boys' ? p.gender : h?.group ?? 'Boys', hostelId,
      room: String(p.room ?? p.room_number ?? ''), phone: String(p.phone ?? ''),
      admissionYear: Number(p.admissionYear ?? p.admission_year) || undefined,
    },
    enrollment: { semesterId: 'current', hostelId, status: 'Active' },
  };
}

const STATUS_MAP: Record<string, Status> = { SUBMITTED: 'WAITING_FOR_VERIFICATION', VERIFIED: 'AWAITING_TAGGING' };
function toBatch(r: Record<string, any>, me: Me): Batch {
  const raw = String(r.status ?? 'SUBMITTED');
  const status: Status = STATUS_MAP[raw] ?? (raw in STATUS ? (raw as Status) : 'WAITING_FOR_VERIFICATION');
  const items: Items = r.items && typeof r.items === 'object' ? r.items : {};
  return {
    rid: `LR-${r.id}`, bid: ['TAGGED', 'IN_LAUNDRY', 'RETURNED', 'READY_FOR_PICKUP', 'COLLECTED'].includes(status) ? `L-${r.id}` : null,
    studentId: me.id, studentName: me.name, hostelId: me.profile?.hostelId ?? '', room: me.profile?.room, semesterId: 'current',
    status, submittedAt: new Date(r.submitted_at ?? Date.now()).toISOString(),
    expectedOn: r.expected_completion ? String(r.expected_completion).slice(0, 10) : null,
    items, original: items, conditions: [], remark: r.remarks ?? '', log: [],
    tokenActive: status === 'READY_FOR_PICKUP', tokenUsed: status === 'COLLECTED',
  };
}

async function myBatches(): Promise<Batch[]> {
  const { email, p } = await profileRow();
  const me = toMe(email, p);
  const { data, error } = await sb().rpc('get_student_laundry_requests');
  if (error) throw fail(error);
  return ((data as Record<string, any>[]) ?? []).map((r) => toBatch(r, me)).sort((a, b) => +new Date(b.submittedAt) - +new Date(a.submittedAt));
}

export const supabaseApi: Api = {
  setSession(token) { if (token === null) void sb().auth.signOut(); },
  auth: {
    async sendOtp(email) {
      const { error } = await sb().auth.signInWithOtp({ email, options: { shouldCreateUser: true } });
      if (error) throw fail(error);
    },
    async verifyOtp(email, code) {
      const { data, error } = await sb().auth.verifyOtp({ email, token: code, type: 'email' });
      if (error) throw fail(error);
      if (!data.session) throw new ApiError('Sign-in failed. Please try again.', 401);
      return { token: data.session.access_token };
    },
  },
  async me() { const { email, p } = await profileRow(); return toMe(email, p); },
  async saveProfile(x) {
    const { error } = await sb().rpc('register_student', {
      p_name: x.name, p_phone: x.phone, p_gender: x.gender, p_hostel_code: x.hostelId, p_room_number: x.room, p_admission_year: x.admissionYear ?? null,
    });
    if (error) throw fail(error);
    const { email, p } = await profileRow();
    return toMe(email, p);
  },
  renewEnrollment: na('Semester renewal'),
  async config() {
    return {
      hostels: HOSTELS, categories: DEFAULT_CATEGORIES.map((name) => ({ name, on: true })), conditions: [...DEFAULT_CONDITIONS],
      semesters: [{ id: 'current', name: semester, start: '', end: '', current: true }],
    };
  },

  async listBatches(q) {
    const s = q?.search?.trim().toLowerCase();
    return (await myBatches()).filter((b) => (!q?.status || q.status.includes(b.status)) && (!s || [b.rid, b.bid ?? ''].some((v) => v.toLowerCase().includes(s))));
  },
  async getBatch(id) {
    const n = id.replace(/\D/g, '');
    const b = (await myBatches()).find((x) => x.rid === `LR-${n}`);
    if (!b) throw new ApiError('Laundry not found', 404);
    return b;
  },
  async submitRequest(items, remark) {
    const list = Object.entries(items).filter(([, q]) => q > 0).map(([name, quantity]) => {
      const category_id = CATEGORY_IDS[name];
      if (!category_id) throw new ApiError(`"${name}" can’t be submitted yet.`);
      return { category_id, quantity };
    });
    if (!list.length) throw new ApiError('Add at least one item.');
    const { data, error } = await sb().rpc('submit_laundry_request', { p_items: list, p_remarks: remark });
    if (error) throw fail(error);
    return supabaseApi.getBatch(`LR-${data}`);
  },
  verifyRequest: na('Verification'), rejectRequest: na('Rejection'), generateBatchId: na('Tagging'), transition: na('Status changes'),
  sendDelayNotice: na('Delay notices'),
  async getPickup() { return null; },
  lookupPickup: na('Pickup scanning'), confirmCollection: na('Collection'),

  async listComplaints() { return []; },
  getComplaint: na('Complaints'), createComplaint: na('Complaints'), addComplaintNote: na('Complaints'),
  advanceComplaint: na('Complaints'), escalateComplaint: na('Complaints'), sendBackComplaint: na('Complaints'),
  async listNotifications() { return []; },
  async markAllRead() {},

  listStudents: na('The student list'), getStudent: na('The student list'), changeHostel: na('Hostel changes'), setStudentActive: na('Student accounts'),
  listStaff: na('The staff list'), addStaff: na('Staff management'), setStaffActive: na('Staff management'), addHostel: na('Hostel management'),
  startSemester: na('Semesters'), approveRenewals: na('Renewals'), addCategory: na('Categories'), toggleCategory: na('Categories'),
  addCondition: na('Conditions'), removeCondition: na('Conditions'), listAudit: na('The audit log'),
};
