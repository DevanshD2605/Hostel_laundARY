import type { Hostel } from '../api/types';

/** Hostel codes and laundry days from the Mangla Laundramat schedule: [collection day, delivery day], 0 = Sunday. */
const SCH: Record<string, [number, number]> = {
  B: [1, 5], H: [1, 5], O: [1, 5], I: [1, 5], Q: [1, 5],
  A: [2, 6], D: [2, 6], J: [2, 6], E: [2, 6], G: [2, 6], N: [2, 6],
  C: [3, 6], K: [3, 6], L: [3, 6], M: [3, 6], PG: [3, 6], PG2: [3, 6],
};
const BOYS = ['A', 'B', 'C', 'D', 'H', 'J', 'K', 'L', 'M', 'O'], GIRLS = ['E', 'G', 'I', 'N', 'Q', 'PG', 'PG2'];
export const hostelLabel = (code: string) => (code.startsWith('PG') ? `${code} Hostel` : `Hostel ${code}`);
export const HOSTELS: Hostel[] = [
  ...BOYS.map((id): Hostel => ({ id, name: hostelLabel(id), group: 'Boys', days: SCH[id] })),
  ...GIRLS.map((id): Hostel => ({ id, name: hostelLabel(id), group: 'Girls', days: SCH[id] })),
];

/** clothing_categories.category_id for each default category (same ids the student page already sends). */
export const CATEGORY_IDS: Record<string, number> = {
  'Shirts': 1, 'T-Shirts': 2, 'Jeans / Pants': 3, 'Shorts': 4, 'Pyjama': 5,
  'Kurta / Salwar': 6, 'Bedsheet': 7, 'Pillow Cover': 8, 'Towel': 9, 'Turban / Dupatta': 10,
};
